function allBanners(){const banners=document.querySelectorAll('.banner-container');if(!banners)return
banners.forEach(banner=>{let playbtn=banner.querySelector('.play-btn');if(!playbtn)return
let frameWrapper=banner.querySelector('iframe');playbtn.addEventListener('click',()=>{banner.classList.add('frame-active');frameWrapper.src=frameWrapper.dataset.src})})
document.addEventListener('keydown',(e)=>{if(e.code==="Escape"){banners.forEach(banner=>{banner.classList.remove('frame-full')})}})}
allBanners()
Fancybox.bind('[data-fancybox]',{Toolbar:{enabled:!0,absolute:!1,display:{left:[],right:["fullscreen","close"],},}});document.addEventListener('contextmenu',event=>event.preventDefault());document.addEventListener('keydown',function(e){if(e.keyCode===123){e.preventDefault();return!1}
if((e.ctrlKey||e.metaKey)&&e.shiftKey&&e.keyCode===73){e.preventDefault();return!1}
if((e.ctrlKey||e.metaKey)&&e.shiftKey&&e.keyCode===74){e.preventDefault();return!1}
if((e.ctrlKey||e.metaKey)&&e.keyCode===85){e.preventDefault();return!1}
if((e.ctrlKey||e.metaKey)&&e.shiftKey&&e.keyCode===67){e.preventDefault();return!1}})